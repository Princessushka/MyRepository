-- 3. скрипты создания структуры БД (с первичными ключами, индексами, внешними ключами)

desc profiles;
alter table profiles 
	add constraint profiles_user_id_fk
		foreign key (user_id) references users(id),
	add constraint profiles_country_id_fk
		foreign key (country_id) references countries(id);		

desc actors;
ALTER TABLE actors 
  ADD CONSTRAINT actors_country_id_fk 
    FOREIGN KEY (country_id) REFERENCES countries(id);
 
desc roles;
alter table roles 
	add constraint roles_actor_id_fk
		foreign key (actor_id) references actors(id),
	add constraint roles_film_id_fk
		foreign key (film_id) references films(id);
		
desc directors;
alter  TABLE directors 
  ADD CONSTRAINT directors_country_id_fk 
    FOREIGN KEY (country_id) REFERENCES countries(id);
    
desc producers;
alter  TABLE producers 
  ADD CONSTRAINT producers_country_id_fk 
    FOREIGN KEY (country_id) REFERENCES countries(id);
    
desc films ;
alter  TABLE films 
  ADD CONSTRAINT films_country_id_fk 
    FOREIGN KEY (country_id) REFERENCES countries(id),
  ADD CONSTRAINT films_genre_id_fk 
    FOREIGN KEY (genre_id) REFERENCES genres(id),
  ADD CONSTRAINT films_director_id_fk 
    FOREIGN KEY (director_id) REFERENCES directors(id),
  ADD CONSTRAINT films_producer_id_fk 
    FOREIGN KEY (producer_id) REFERENCES producers(id);  
   
desc ratings;
alter table ratings 
	add constraint ratings_user_id_fk
		foreign key (user_id) references users(id),
	add constraint ratings_film_id_fk
		foreign key (film_id) references films(id);
	
desc reviews ;
alter table reviews 	
add constraint reviews_user_id_fk
		foreign key (user_id) references users(id),
	add constraint reviews_film_id_fk
		foreign key (film_id) references films(id);		
	
	
CREATE index films_created_year_idx on films(created_year);

CREATE index films_genre_id_idx on films(genre_id);

CREATE INDEX users_email_idx ON users(email);


		