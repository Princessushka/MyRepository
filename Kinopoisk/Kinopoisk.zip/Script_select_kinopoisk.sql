-- 6. скрипты характерных выборок (включающие группировки, JOIN'ы, вложенные таблицы):

select * from films where created_year = 1999;


select name, created_year from films where genre_id = 3;


select film_id, name, SUM(rating) as rating
from ratings 
 left join films 
 	on film_id = films.id
 	group by film_id;
 
 
select *
from ratings 
 left join films 
 	on film_id = films.id
 	where film_id = 77;
 	

 select id, name, created_year,
 (select body from reviews  where film_id = 7) as review
 from films
 where id = 7;


select id, name, created_year,
 (select name from countries  where id = films.country_id) as country
 from films
 where id = 7;

-- 7. представления (минимум 2);

select f.name, c.name
from films as f
join countries as c
on f.country_id = c.id;

select r.hero_name, a.first_name, a.last_name 
from roles as r
 join actors as a
 on r.actor_id = a.id;
 	
-- 8. хранимые процедуры / триггеры;
DELIMITER //
CREATE TRIGGER update_producer AFTER INSERT ON films
FOR EACH ROW BEGIN
UPDATE producers SET movies_count = movies_count + 1  where id = NEW.producer_id;
END//

